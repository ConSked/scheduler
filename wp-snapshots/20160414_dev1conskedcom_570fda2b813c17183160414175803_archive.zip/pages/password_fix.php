<?php
require_once('db/WorkerLogin.php');

WorkerLogin::password_change(3, 'LIhiggs61');
?>

DROP TRIGGER IF EXISTS shiftassignment_insert;
DROP TRIGGER IF EXISTS shiftassignment_delete;
DROP TRIGGER IF EXISTS workerrole_update;
DROP TRIGGER IF EXISTS workerexpo_delete;
DROP TRIGGER IF EXISTS worker_insert;
DROP TRIGGER IF EXISTS worker_update;
DROP TRIGGER IF EXISTS workerexpo_insert;
DROP TRIGGER IF EXISTS job_insert;

<?php /* $Id: header.php 2005 2012-09-17 16:49:22Z ecgero $ Copyright (c) ConSked, LLC. All Rights Reserved. */ ?>

<div id="header">
    <table style="width: 100%">
        <tr>
            <td style="vertical-align: middle; text-align: left; width: 33%">
	            <img src="images/intlogo.png" width="344" height="84" alt="" />
            </td>
            <td style="vertical-align: middle; text-align: center; width: 34%">
                <div style="width: 468pt">
                    <script async
                        src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js">
                    </script>
                    <ins class="adsbygoogle"
                        style="display:inline-block;width:468px;height:60px"
                        data-ad-client = "pub-8102958922361899">
                    </ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </td>
            <td style="width: 33%"> 
            </td>
        </tr>
    </table>
</div><!-- header -->

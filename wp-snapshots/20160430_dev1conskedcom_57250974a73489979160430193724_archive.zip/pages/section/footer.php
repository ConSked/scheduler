<?php  ?>

<div id="footer">
	Copyright &copy; 2016 <?php echo(SITE_NAME); ?>.  All rights reserved.
</div><!-- footer -->

<?php // $Id: exception.php 245 2012-05-22 01:43:40Z preston $ Copyright (c) Preston C. Urka. All Rights Reserved.

class SWWATException extends Exception
{
} // SWWATException

class ParameterSWWATException extends SWWATException
{
} // ParameterSWWATException

?>
